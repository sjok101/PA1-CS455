1. Download and install python3
2. Run the command...

"python3 my-dns-client.py <host-name>"